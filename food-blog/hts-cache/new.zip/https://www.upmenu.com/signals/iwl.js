<!DOCTYPE html>
<html lang="en-US"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page not found | UpMenu</title>
    <meta name="facebook-domain-verification" content="4f65zdiu11yeg0x3efmifu4utbl398">
    <meta name="ahrefs-site-verification" content="d9cf7bb0dcdf6c36f5afbe12ee440cbc2c912a090551fd4899563d1af4b22b93">
    <link rel="Shortcut icon" href="https://www.upmenu.com/wp-content/themes/upmenucom/assets/images/favicon.ico">
    <script data-cfasync="false" data-no-defer="1" data-no-minify="1" data-no-optimize="1">var ewww_webp_supported=!1;function check_webp_feature(A,e){var w;e=void 0!==e?e:function(){},ewww_webp_supported?e(ewww_webp_supported):((w=new Image).onload=function(){ewww_webp_supported=0<w.width&&0<w.height,e&&e(ewww_webp_supported)},w.onerror=function(){e&&e(!1)},w.src="data:image/webp;base64,"+{alpha:"UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAARBxAR/Q9ERP8DAABWUDggGAAAABQBAJ0BKgEAAQAAAP4AAA3AAP7mtQAAAA=="}[A])}check_webp_feature("alpha");</script><script data-cfasync="false" data-no-defer="1" data-no-minify="1" data-no-optimize="1">var Arrive=function(c,w){"use strict";if(c.MutationObserver&&"undefined"!=typeof HTMLElement){var r,a=0,u=(r=HTMLElement.prototype.matches||HTMLElement.prototype.webkitMatchesSelector||HTMLElement.prototype.mozMatchesSelector||HTMLElement.prototype.msMatchesSelector,{matchesSelector:function(e,t){return e instanceof HTMLElement&&r.call(e,t)},addMethod:function(e,t,r){var a=e[t];e[t]=function(){return r.length==arguments.length?r.apply(this,arguments):"function"==typeof a?a.apply(this,arguments):void 0}},callCallbacks:function(e,t){t&&t.options.onceOnly&&1==t.firedElems.length&&(e=[e[0]]);for(var r,a=0;r=e[a];a++)r&&r.callback&&r.callback.call(r.elem,r.elem);t&&t.options.onceOnly&&1==t.firedElems.length&&t.me.unbindEventWithSelectorAndCallback.call(t.target,t.selector,t.callback)},checkChildNodesRecursively:function(e,t,r,a){for(var i,n=0;i=e[n];n++)r(i,t,a)&&a.push({callback:t.callback,elem:i}),0<i.childNodes.length&&u.checkChildNodesRecursively(i.childNodes,t,r,a)},mergeArrays:function(e,t){var r,a={};for(r in e)e.hasOwnProperty(r)&&(a[r]=e[r]);for(r in t)t.hasOwnProperty(r)&&(a[r]=t[r]);return a},toElementsArray:function(e){return e=void 0!==e&&("number"!=typeof e.length||e===c)?[e]:e}}),e=(l.prototype.addEvent=function(e,t,r,a){a={target:e,selector:t,options:r,callback:a,firedElems:[]};return this._beforeAdding&&this._beforeAdding(a),this._eventsBucket.push(a),a},l.prototype.removeEvent=function(e){for(var t,r=this._eventsBucket.length-1;t=this._eventsBucket[r];r--)e(t)&&(this._beforeRemoving&&this._beforeRemoving(t),(t=this._eventsBucket.splice(r,1))&&t.length&&(t[0].callback=null))},l.prototype.beforeAdding=function(e){this._beforeAdding=e},l.prototype.beforeRemoving=function(e){this._beforeRemoving=e},l),t=function(i,n){var o=new e,l=this,s={fireOnAttributesModification:!1};return o.beforeAdding(function(t){var e=t.target;e!==c.document&&e!==c||(e=document.getElementsByTagName("html")[0]);var r=new MutationObserver(function(e){n.call(this,e,t)}),a=i(t.options);r.observe(e,a),t.observer=r,t.me=l}),o.beforeRemoving(function(e){e.observer.disconnect()}),this.bindEvent=function(e,t,r){t=u.mergeArrays(s,t);for(var a=u.toElementsArray(this),i=0;i<a.length;i++)o.addEvent(a[i],e,t,r)},this.unbindEvent=function(){var r=u.toElementsArray(this);o.removeEvent(function(e){for(var t=0;t<r.length;t++)if(this===w||e.target===r[t])return!0;return!1})},this.unbindEventWithSelectorOrCallback=function(r){var a=u.toElementsArray(this),i=r,e="function"==typeof r?function(e){for(var t=0;t<a.length;t++)if((this===w||e.target===a[t])&&e.callback===i)return!0;return!1}:function(e){for(var t=0;t<a.length;t++)if((this===w||e.target===a[t])&&e.selector===r)return!0;return!1};o.removeEvent(e)},this.unbindEventWithSelectorAndCallback=function(r,a){var i=u.toElementsArray(this);o.removeEvent(function(e){for(var t=0;t<i.length;t++)if((this===w||e.target===i[t])&&e.selector===r&&e.callback===a)return!0;return!1})},this},i=new function(){var s={fireOnAttributesModification:!1,onceOnly:!1,existing:!1};function n(e,t,r){return!(!u.matchesSelector(e,t.selector)||(e._id===w&&(e._id=a++),-1!=t.firedElems.indexOf(e._id)))&&(t.firedElems.push(e._id),!0)}var c=(i=new t(function(e){var t={attributes:!1,childList:!0,subtree:!0};return e.fireOnAttributesModification&&(t.attributes=!0),t},function(e,i){e.forEach(function(e){var t=e.addedNodes,r=e.target,a=[];null!==t&&0<t.length?u.checkChildNodesRecursively(t,i,n,a):"attributes"===e.type&&n(r,i)&&a.push({callback:i.callback,elem:r}),u.callCallbacks(a,i)})})).bindEvent;return i.bindEvent=function(e,t,r){t=void 0===r?(r=t,s):u.mergeArrays(s,t);var a=u.toElementsArray(this);if(t.existing){for(var i=[],n=0;n<a.length;n++)for(var o=a[n].querySelectorAll(e),l=0;l<o.length;l++)i.push({callback:r,elem:o[l]});if(t.onceOnly&&i.length)return r.call(i[0].elem,i[0].elem);setTimeout(u.callCallbacks,1,i)}c.call(this,e,t,r)},i},o=new function(){var a={};function i(e,t){return u.matchesSelector(e,t.selector)}var n=(o=new t(function(){return{childList:!0,subtree:!0}},function(e,r){e.forEach(function(e){var t=e.removedNodes,e=[];null!==t&&0<t.length&&u.checkChildNodesRecursively(t,r,i,e),u.callCallbacks(e,r)})})).bindEvent;return o.bindEvent=function(e,t,r){t=void 0===r?(r=t,a):u.mergeArrays(a,t),n.call(this,e,t,r)},o};d(HTMLElement.prototype),d(NodeList.prototype),d(HTMLCollection.prototype),d(HTMLDocument.prototype),d(Window.prototype);var n={};return s(i,n,"unbindAllArrive"),s(o,n,"unbindAllLeave"),n}function l(){this._eventsBucket=[],this._beforeAdding=null,this._beforeRemoving=null}function s(e,t,r){u.addMethod(t,r,e.unbindEvent),u.addMethod(t,r,e.unbindEventWithSelectorOrCallback),u.addMethod(t,r,e.unbindEventWithSelectorAndCallback)}function d(e){e.arrive=i.bindEvent,s(i,e,"unbindArrive"),e.leave=o.bindEvent,s(o,e,"unbindLeave")}}(window,void 0),ewww_webp_supported=!1;function check_webp_feature(e,t){var r;ewww_webp_supported?t(ewww_webp_supported):((r=new Image).onload=function(){ewww_webp_supported=0<r.width&&0<r.height,t(ewww_webp_supported)},r.onerror=function(){t(!1)},r.src="data:image/webp;base64,"+{alpha:"UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAARBxAR/Q9ERP8DAABWUDggGAAAABQBAJ0BKgEAAQAAAP4AAA3AAP7mtQAAAA==",animation:"UklGRlIAAABXRUJQVlA4WAoAAAASAAAAAAAAAAAAQU5JTQYAAAD/////AABBTk1GJgAAAAAAAAAAAAAAAAAAAGQAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcA"}[e])}function ewwwLoadImages(e){if(e){for(var t=document.querySelectorAll(".batch-image img, .image-wrapper a, .ngg-pro-masonry-item a, .ngg-galleria-offscreen-seo-wrapper a"),r=0,a=t.length;r<a;r++)ewwwAttr(t[r],"data-src",t[r].getAttribute("data-webp")),ewwwAttr(t[r],"data-thumbnail",t[r].getAttribute("data-webp-thumbnail"));for(var i=document.querySelectorAll(".rev_slider ul li"),r=0,a=i.length;r<a;r++){ewwwAttr(i[r],"data-thumb",i[r].getAttribute("data-webp-thumb"));for(var n=1;n<11;)ewwwAttr(i[r],"data-param"+n,i[r].getAttribute("data-webp-param"+n)),n++}for(r=0,a=(i=document.querySelectorAll(".rev_slider img")).length;r<a;r++)ewwwAttr(i[r],"data-lazyload",i[r].getAttribute("data-webp-lazyload"));for(var o=document.querySelectorAll("div.woocommerce-product-gallery__image"),r=0,a=o.length;r<a;r++)ewwwAttr(o[r],"data-thumb",o[r].getAttribute("data-webp-thumb"))}for(var l=document.querySelectorAll("video"),r=0,a=l.length;r<a;r++)ewwwAttr(l[r],"poster",e?l[r].getAttribute("data-poster-webp"):l[r].getAttribute("data-poster-image"));for(var s,c=document.querySelectorAll("img.ewww_webp_lazy_load"),r=0,a=c.length;r<a;r++)e&&(ewwwAttr(c[r],"data-lazy-srcset",c[r].getAttribute("data-lazy-srcset-webp")),ewwwAttr(c[r],"data-srcset",c[r].getAttribute("data-srcset-webp")),ewwwAttr(c[r],"data-lazy-src",c[r].getAttribute("data-lazy-src-webp")),ewwwAttr(c[r],"data-src",c[r].getAttribute("data-src-webp")),ewwwAttr(c[r],"data-orig-file",c[r].getAttribute("data-webp-orig-file")),ewwwAttr(c[r],"data-medium-file",c[r].getAttribute("data-webp-medium-file")),ewwwAttr(c[r],"data-large-file",c[r].getAttribute("data-webp-large-file")),null!=(s=c[r].getAttribute("srcset"))&&!1!==s&&s.includes("R0lGOD")&&ewwwAttr(c[r],"src",c[r].getAttribute("data-lazy-src-webp"))),c[r].className=c[r].className.replace(/\bewww_webp_lazy_load\b/,"");for(var w=document.querySelectorAll(".ewww_webp"),r=0,a=w.length;r<a;r++)e?(ewwwAttr(w[r],"srcset",w[r].getAttribute("data-srcset-webp")),ewwwAttr(w[r],"src",w[r].getAttribute("data-src-webp")),ewwwAttr(w[r],"data-orig-file",w[r].getAttribute("data-webp-orig-file")),ewwwAttr(w[r],"data-medium-file",w[r].getAttribute("data-webp-medium-file")),ewwwAttr(w[r],"data-large-file",w[r].getAttribute("data-webp-large-file")),ewwwAttr(w[r],"data-large_image",w[r].getAttribute("data-webp-large_image")),ewwwAttr(w[r],"data-src",w[r].getAttribute("data-webp-src"))):(ewwwAttr(w[r],"srcset",w[r].getAttribute("data-srcset-img")),ewwwAttr(w[r],"src",w[r].getAttribute("data-src-img"))),w[r].className=w[r].className.replace(/\bewww_webp\b/,"ewww_webp_loaded");window.jQuery&&jQuery.fn.isotope&&jQuery.fn.imagesLoaded&&(jQuery(".fusion-posts-container-infinite").imagesLoaded(function(){jQuery(".fusion-posts-container-infinite").hasClass("isotope")&&jQuery(".fusion-posts-container-infinite").isotope()}),jQuery(".fusion-portfolio:not(.fusion-recent-works) .fusion-portfolio-wrapper").imagesLoaded(function(){jQuery(".fusion-portfolio:not(.fusion-recent-works) .fusion-portfolio-wrapper").isotope()}))}function ewwwWebPInit(e){ewwwLoadImages(e),ewwwNggLoadGalleries(e),document.arrive(".ewww_webp",function(){ewwwLoadImages(e)}),document.arrive(".ewww_webp_lazy_load",function(){ewwwLoadImages(e)}),document.arrive("videos",function(){ewwwLoadImages(e)}),"loading"==document.readyState?document.addEventListener("DOMContentLoaded",ewwwJSONParserInit):("undefined"!=typeof galleries&&ewwwNggParseGalleries(e),ewwwWooParseVariations(e))}function ewwwAttr(e,t,r){null!=r&&!1!==r&&e.setAttribute(t,r)}function ewwwJSONParserInit(){"undefined"!=typeof galleries&&check_webp_feature("alpha",ewwwNggParseGalleries),check_webp_feature("alpha",ewwwWooParseVariations)}function ewwwWooParseVariations(e){if(e)for(var t=document.querySelectorAll("form.variations_form"),r=0,a=t.length;r<a;r++){var i=t[r].getAttribute("data-product_variations"),n=!1;try{for(var o in i=JSON.parse(i))void 0!==i[o]&&void 0!==i[o].image&&(void 0!==i[o].image.src_webp&&(i[o].image.src=i[o].image.src_webp,n=!0),void 0!==i[o].image.srcset_webp&&(i[o].image.srcset=i[o].image.srcset_webp,n=!0),void 0!==i[o].image.full_src_webp&&(i[o].image.full_src=i[o].image.full_src_webp,n=!0),void 0!==i[o].image.gallery_thumbnail_src_webp&&(i[o].image.gallery_thumbnail_src=i[o].image.gallery_thumbnail_src_webp,n=!0),void 0!==i[o].image.thumb_src_webp&&(i[o].image.thumb_src=i[o].image.thumb_src_webp,n=!0));n&&ewwwAttr(t[r],"data-product_variations",JSON.stringify(i))}catch(e){}}}function ewwwNggParseGalleries(e){if(e)for(var t in galleries){var r=galleries[t];galleries[t].images_list=ewwwNggParseImageList(r.images_list)}}function ewwwNggLoadGalleries(e){e&&document.addEventListener("ngg.galleria.themeadded",function(e,t){window.ngg_galleria._create_backup=window.ngg_galleria.create,window.ngg_galleria.create=function(e,t){var r=$(e).data("id");return galleries["gallery_"+r].images_list=ewwwNggParseImageList(galleries["gallery_"+r].images_list),window.ngg_galleria._create_backup(e,t)}})}function ewwwNggParseImageList(e){for(var t in e){var r=e[t];if(void 0!==r["image-webp"]&&(e[t].image=r["image-webp"],delete e[t]["image-webp"]),void 0!==r["thumb-webp"]&&(e[t].thumb=r["thumb-webp"],delete e[t]["thumb-webp"]),void 0!==r.full_image_webp&&(e[t].full_image=r.full_image_webp,delete e[t].full_image_webp),void 0!==r.srcsets)for(var a in r.srcsets)nggSrcset=r.srcsets[a],void 0!==r.srcsets[a+"-webp"]&&(e[t].srcsets[a]=r.srcsets[a+"-webp"],delete e[t].srcsets[a+"-webp"]);if(void 0!==r.full_srcsets)for(var i in r.full_srcsets)nggFSrcset=r.full_srcsets[i],void 0!==r.full_srcsets[i+"-webp"]&&(e[t].full_srcsets[i]=r.full_srcsets[i+"-webp"],delete e[t].full_srcsets[i+"-webp"])}return e}check_webp_feature("alpha",ewwwWebPInit);</script><meta name='robots' content='noindex, follow' />
<script id="cookieyes" type="text/javascript" src="https://cdn-cookieyes.com/client_data/624aebdf46b992f1b2726f3f/script.js"></script>
	<!-- This site is optimized with the Yoast SEO plugin v21.5 - https://yoast.com/wordpress/plugins/seo/ -->
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found | UpMenu" />
	<meta property="og:site_name" content="UpMenu" />
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//plausible.io' />
<link rel='dns-prefetch' href='//unpkg.com' />
<link rel='stylesheet' id='wp-block-library-css' href='https://www.upmenu.com/wp-includes/css/dist/block-library/style.min.css?ver=6.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='activecampaign-form-block-css' href='https://www.upmenu.com/wp-content/plugins/activecampaign-subscription-forms/activecampaign-form-block/build/style-index.css?ver=1696923681' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='wpml-legacy-horizontal-list-0-css' href='//www.upmenu.com/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-list-horizontal/style.css?ver=1' type='text/css' media='all' />
<link rel='stylesheet' id='wpml-tm-admin-bar-css' href='https://www.upmenu.com/wp-content/plugins/wpml-translation-management/res/css/admin-bar-style.css?ver=2.9.10' type='text/css' media='all' />
<link rel='stylesheet' id='new-css' href='https://www.upmenu.com/wp-content/themes/upmenucom/assets/css/new.min.css?ver=6.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://www.upmenu.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.23.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://www.upmenu.com/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.17.3' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://www.upmenu.com/wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min.css?ver=5.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-2031-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-2031.css?ver=1701268603' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://www.upmenu.com/wp-content/plugins/elementor-pro/assets/css/frontend-lite.min.css?ver=3.17.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/global.css?ver=1701268603' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-17924-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-17924.css?ver=1701268608' type='text/css' media='all' />
<link rel='stylesheet' id='tablepress-default-css' href='https://www.upmenu.com/wp-content/tablepress-combined.min.css?ver=22' type='text/css' media='all' />
<link rel='stylesheet' id='site-reviews-css' href='https://www.upmenu.com/wp-content/plugins/site-reviews/assets/styles/default.css?ver=6.11.4' type='text/css' media='all' />
<style id='site-reviews-inline-css' type='text/css'>
.glsr-star-empty,.glsr-star-rating--stars[class*=" s"]>span{background-image:url(https://www.upmenu.com/wp-content/plugins/site-reviews/assets/images/stars/default/star-empty.svg)!important}.glsr-field-is-invalid .glsr-star-rating--stars[class*=" s"]>span{background-image:url(https://www.upmenu.com/wp-content/plugins/site-reviews/assets/images/stars/default/star-error.svg)!important}.glsr-star-half{background-image:url(https://www.upmenu.com/wp-content/plugins/site-reviews/assets/images/stars/default/star-half.svg)!important}.glsr-star-full,.glsr-star-rating--stars[class*=" s"]>span.gl-active,.glsr-star-rating--stars[class*=" s"]>span.gl-active.gl-selected{background-image:url(https://www.upmenu.com/wp-content/plugins/site-reviews/assets/images/stars/default/star-full.svg)!important}

</style>
<link rel='stylesheet' id='ecs-styles-css' href='https://www.upmenu.com/wp-content/plugins/ele-custom-skin/assets/css/ecs-style.css?ver=3.1.7' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-2372-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-2372.css?ver=1669652842' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-4646-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-4646.css?ver=1659625909' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-4668-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-4668.css?ver=1660222932' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-6921-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-6921.css?ver=1661356707' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-7000-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-7000.css?ver=1678287798' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-7782-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-7782.css?ver=1669653006' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-7784-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-7784.css?ver=1669653042' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-13097-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-13097.css?ver=1691396706' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-13443-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-13443.css?ver=1690995761' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-13445-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-13445.css?ver=1690995873' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-15760-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-15760.css?ver=1680796354' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-29621-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-29621.css?ver=1693835539' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-34435-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-34435.css?ver=1693403113' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-35839-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-35839.css?ver=1693404133' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-35844-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-35844.css?ver=1693404192' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-40529-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-40529.css?ver=1693311264' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Inter%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=swap&#038;ver=6.4.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://www.upmenu.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://www.upmenu.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script type="text/javascript" defer data-domain='upmenu.com' data-api='https://plausible.io/api/event' src="https://plausible.io/js/plausible.outbound-links.js?ver=1.3.6" id="plausible"></script>
<script type="text/javascript" id="plausible-analytics-js-after">
/* <![CDATA[ */
window.plausible = window.plausible || function() { (window.plausible.q = window.plausible.q || []).push(arguments) }
document.addEventListener('DOMContentLoaded', function () { plausible('404', { props: { path: document.location.pathname } }); });
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://unpkg.com/feather-icons@4.29.1/dist/feather.min.js?ver=6.4.2" id="feather-icons-js"></script>
<script type="text/javascript" id="ecs_ajax_load-js-extra">
/* <![CDATA[ */
var ecs_ajax_params = {"ajaxurl":"https:\/\/www.upmenu.com\/wp-admin\/admin-ajax.php","posts":"{\"error\":\"404\",\"m\":\"\",\"p\":0,\"post_parent\":\"\",\"subpost\":\"\",\"subpost_id\":\"\",\"attachment\":\"\",\"attachment_id\":0,\"name\":\"\",\"pagename\":\"\",\"page_id\":0,\"second\":\"\",\"minute\":\"\",\"hour\":\"\",\"day\":0,\"monthnum\":0,\"year\":0,\"w\":0,\"category_name\":\"\",\"tag\":\"\",\"cat\":\"\",\"tag_id\":\"\",\"author\":\"\",\"author_name\":\"\",\"feed\":\"\",\"tb\":\"\",\"paged\":0,\"meta_key\":\"\",\"meta_value\":\"\",\"preview\":\"\",\"s\":\"\",\"sentence\":\"\",\"title\":\"\",\"fields\":\"\",\"menu_order\":\"\",\"embed\":\"\",\"category__in\":[],\"category__not_in\":[],\"category__and\":[],\"post__in\":[],\"post__not_in\":[],\"post_name__in\":[],\"tag__in\":[],\"tag__not_in\":[],\"tag__and\":[],\"tag_slug__in\":[],\"tag_slug__and\":[],\"post_parent__in\":[],\"post_parent__not_in\":[],\"author__in\":[],\"author__not_in\":[],\"search_columns\":[],\"ignore_sticky_posts\":false,\"suppress_filters\":false,\"cache_results\":true,\"update_post_term_cache\":true,\"update_menu_item_cache\":false,\"lazy_load_term_meta\":true,\"update_post_meta_cache\":true,\"post_type\":\"\",\"posts_per_page\":15,\"nopaging\":false,\"comments_per_page\":\"50\",\"no_found_rows\":false,\"order\":\"DESC\"}"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/ele-custom-skin/assets/js/ecs_ajax_pagination.js?ver=3.1.7" id="ecs_ajax_load-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/ele-custom-skin/assets/js/ecs.js?ver=3.1.7" id="ecs-script-js"></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.upmenu.com/xmlrpc.php?rsd" />
<meta name="generator" content="WPML ver:4.3.17 stt:1,40,2;" />
		<script type="text/javascript">
				(function(c,l,a,r,i,t,y){
					c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;
					t.src="https://www.clarity.ms/tag/"+i+"?ref=wordpress";y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
				})(window, document, "clarity", "script", "cu5q5dpkad");
		</script>
		<link rel="dns-prefetch" href="https://www.googletagmanager.com/">
<!-- CookieYes with Consent Mode -->
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag("consent", "default", {
        ad_storage: "denied",
        analytics_storage: "denied",
        functionality_storage: "denied",
        personalization_storage: "denied",
        security_storage: "granted",
        wait_for_update: 2000,
    });
    gtag("set", "ads_data_redaction", true);
    gtag("set", "url_passthrough", true);
</script>
<!-- CookieYes with Consent Mode -->
<script>
window.dataLayer = window.dataLayer || [];
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-WNFVKPT');</script>
<!-- End Google Tag Manager --><meta name="generator" content="Elementor 3.17.3; features: e_dom_optimization, e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
<meta property="fb:app_id" content="785955475778577" /><noscript><style>.lazyload[data-src]{display:none !important;}</style></noscript><style>.lazyload{background-image:none !important;}.lazyload:before{background-image:none !important;}</style><style>.wp-block-gallery.is-cropped .blocks-gallery-item picture{height:100%;width:100%;}</style><link rel="icon" href="https://www.upmenu.com/wp-content/uploads/2022/10/cropped-favicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.upmenu.com/wp-content/uploads/2022/10/cropped-favicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.upmenu.com/wp-content/uploads/2022/10/cropped-favicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.upmenu.com/wp-content/uploads/2022/10/cropped-favicon-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			/* @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@800&display=swap'); */

/* AB HERO */
#hero1{
	display:none;
}


.by-stripe h4:after {
	content: '';
	width: 75px;
	height: 25px;
	display: inline-block;
	margin-left: 5px;
	margin-top: -5px;
	background: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/by-stripe.svg) center center no-repeat;
	background-size: contain;
	vertical-align: middle;
}
html[lang="pl-PL"] .by-stripe h4:after {
	width: 90px;
	background-image: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/by-stripe-pl.svg);
}

.by-payu h4:after {
	content: '';
	width: 75px;
	height: 25px;
	display: inline-block;
	margin-left: 5px;
	margin-top: -5px;
	background: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/by-payu.svg) center center no-repeat;
	background-size: contain;
	vertical-align: middle;
}
html[lang="pl-PL"] .by-payu h4:after {
	width: 90px;
	background-image: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/by-payu-pl.svg);
}

.by-adyen h4:after {
	content: '';
	width: 75px;
	height: 25px;
	display: inline-block;
	margin-left: 5px;
	margin-top: -5px;
	background: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/by-adyen.svg) center center no-repeat;
	background-size: contain;
	vertical-align: middle;
}
html[lang="pl-PL"] .by-adyen h4:after {
	width: 90px;
	background-image: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/by-adyen-pl.svg);
}

/* h1 overwrite */
h1{
	font-size:56px !important;
	line-height:1.25em !important;
}

@media screen and (max-width:1024px){
	h1{
		font-size: 40px !important;
	}
	.single-post .elementor-widget-theme-post-content h2 {
		font-size: 36px !important;
		line-height: 1.4 !important;
	}
	.single-post .elementor-widget-theme-post-content h3 {
		font-size: 28px !important;
	}
	.single-post .elementor-widget-theme-post-content h4 {
		font-size: 22px !important;
	}
}

.fas {
	    font-family: "Font Awesome 5 Free";
	font-style: initial;
}

html[lang="pl-PL"] .elementor-21019 .elementor-element.elementor-element-255c044 .elementor-heading-title {
	text-transform: initial;
}
html[lang="pl-PL"] .elementor-15760 .elementor-element.elementor-element-9a20841 .elementor-heading-title {
	text-transform: initial;
}

.cky-btn-revisit-wrapper {
	display: none !important
}

.no-last-padding{
	margin-bottom:0 !important;
}

.elementor-menu-anchor {
	position: relative;
  top: -92px;
}

.elementor-testimonial, .elementor-post__excerpt {
font-family: "Inter" !important;
}

/* btn override */

.btn{
	font-family:"Inter";
	border-radius:16px;
	padding-top:15px;
	padding-bottom:15px;
}

.elementor-widget-button .elementor-button{
	font-family:"Inter";
}

.btn-shadow a{
	box-shadow: 0px 7px 20px rgba(143, 83, 161, 0.2);
}

/* breadcrumbs */

p#breadcrumbs img{
	width:20px;
	position:relative;
	top:4px;
	opacity:0.3;
}

p#breadcrumbs img, p#breadcrumbs a{
	margin-right:5px;
}

.elementor-breadcrumbs {
    border-bottom: 1px solid #f4f4f4;
    padding-bottom: 12px;
    font-family: "Inter", Sans-serif;
    font-size: 16px;
    font-weight: 400;
}
.elementor-breadcrumbs ol {
    margin: 0;
    padding: 0;
}
.elementor-breadcrumbs ol li {
    list-style: none;
    display: inline-block;
}
.elementor-breadcrumbs ol li:not(:last-child):after {
    content: '';
    width: 20px;
    height: 20px;
    display: inline-block;
    vertical-align: middle;
    margin-left: 6px;
    margin-right: 6px;
    margin-bottom: 5px;
    opacity: 0.3;
    background: url(https://www.upmenu.com/wp-content/uploads/2022/11/fi_chevron-up.png.webp) center center no-repeat;
    background-size: contain;
}
@media(max-width: 767px) {
    .elementor-breadcrumbs {
        font-size: 14px;
    }
}

/* calculator */

form div.range-wrap{
	max-width:400px !important
}

.text-center .result{
	background: none !important;
	padding: 0 !important;
	font-size:42px !important
}

/* theme store */

.themestore-item-container{
    background-size:100%;
	background-position:0 0, center;
	border-radius:8px;
	border:1px solid #E4E4E4;
	transition:3.5s all ease-in-out !important;
	overflow:hidden;
	filter: drop-shadow(0px 23px 26px rgba(68, 47, 84, 0.10));
}

.themestore-item-container:hover{
    background-position:0 100%, center !important;
}

.template-item-btns{
    opacity:0;
    transition:.2s all ease-in-out !important;
}

.themestore-item-container:hover .template-item-btns{
    opacity: 1;
}

.elementor-widget-container h1{
	margin:0;
}

.elementor-widget-text-editor ul li {
    font-family: "Inter" !important;
}

.cookie-container {
    background: rgba(38, 31, 45, 0.95);
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 20px;
    z-index: 9999999999;
    color: #fff;
    font-size: 14px;
    line-height: 1.4;
    display: flex;
    align-items: center;
}
.cookie-container .cn-text-container {
    padding-right: 25px;
}
.cookie-container .cn-text-container a {
    color: #fff;
    text-decoration: underline;
} 
@media(max-width: 767px) {
    .cookie-container {
        flex-wrap: wrap;
        font-size: 13px;
    }
    .cookie-container .cn-text-container {
        padding: 0 0 15px 0;
    }
} 

header.header .container {
	max-width: 1200px;
}
@media(min-width: 1230px) {
	header.header .container {
		padding: 0;
	}
}

.elementor-headline-text-wrapper {
	vertical-align: middle !important;
} 

.elementor-widget-search-form {
	margin-left: auto;
	margin-right: auto;
}
.elementor-widget-search-form .elementor-search-form__input {background: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/search.svg) 20px center no-repeat !important;
padding-left: 55px !important;
}
.elementor-widget-search-form .elementor-search-form__submit {
	height: 52px;
	margin: 8px;
	border-radius: 50px !important;
	padding-left: 10px !important;
	padding-right: 10px !important;
	min-width: 94px !important;
	padding-bottom: 4px;
}

.category-title {
	position: relative;
}
.category-title:before {
	content: '';
	width: 100%;
	height: 1px;
	display: block;
	position: absolute;
	top: 50%;
	left: 0;
	background: #E4E4E4;
}
.category-title .elementor-heading-title {
	display: inline-block;
	position: relative;
	background: #fff;
	padding-right: 24px;
}

.elementor-page .container {
	max-width: 1200px;
}

.elementor-page .elementor-widget-heading span{
	/*color:#8B38CB*/
}

.mockup-shadow{
	filter: drop-shadow(0px 23px 26px rgba(68, 47, 84, 0.25));
}

.std-shadow{
	box-shadow: 0px 12px 16px rgba(0, 0, 0, 0.11);
}

.yellow-box .elementor-widget-video .elementor-widget-container{
	overflow:visible;
}

.yellow-box video{
	border-radius:16px;
}

.yellow-box .elementor-widget-container{
  position:relative;
  z-index:1;
}

.yellow-box .elementor-widget-container:after{
  content:"";
  position:absolute;
  width:150px;
  height:150px;
  background-color:#FDB735;
  border-radius:16px;
	z-index:-1;
}

.yellow-box.yellow-box--topright .elementor-widget-container:after{
  top:-40px;
  right:-40px;
}

.yellow-box.yellow-box--topleft .elementor-widget-container:after{
  top:-40px;
  left:-40px;
}

.yellow-box.yellow-box--bottomright .elementor-widget-container:after{
  bottom:-40px;
  right:-40px;
}

.section-overflow{
	overflow:hidden;
}

.purple-bg .p, .purple-bg a {
	color: #fff;
}

/* mega menu */

.header.header .container ul li .megamenu.full{
	justify-content:center;
}

header.header .container ul li .megamenu ul li a{
	font-size:16px
}

header.header .container ul li .megamenu ul li a span {
    font-size: 14px;
    color: #B0BCCA;
}

/* elementor sections paddings */
.hero-padding{
	padding-top:200px;
	padding-bottom:110px;
}

.hero-breadcrumbs-padding{
	padding-top:20px;
	padding-bottom:110px;
}

.breadcrumbs-padding{
	padding-top:120px;
	padding-bottom:0px;
	background-color:#fff;
}

@media screen and (max-width:767px){
	.hero-padding{
	padding-top:80px;
	padding-bottom:80px;
}
	
	.hero-breadcrumbs-padding{
	padding-top:0px;
	padding-bottom:80px;
}
	
	.breadcrumbs-padding{
	padding-top:50px;
	padding-bottom:0px;
}

}

.section-standard{
	padding-top:80px;
	padding-bottom:80px;
}

/* app carousel with frame */

.apps-carousel .swiper-container{
  position:relative;
  overflow:visible;
  overflow-x:hidden;
  padding-bottom:60px;
}

.apps-carousel .swiper-container:after{
  content:"";
  position:absolute;
  height:calc(100% - 60px);
  width:500px;
  top:0;
  left: 0; 
  right: 0; 
  margin-left: auto; 
  margin-right: auto; 
  width: 350px;
  z-index:2;
  background-image:url("https://www.upmenu.com/wp-content/uploads/2022/08/phone-frame.png");
  background-size:contain;
  background-position:center;
  background-repeat:no-repeat;
  
}

.apps-carousel .swiper-container img{
  transform:scale(0.97);
  border-radius:16px;
  filter: drop-shadow(0px 23px 26px rgba(68, 47, 84, 0.25));
}

.app-carousel .swiper-pagination{
  position:relative;
}

/* @media(max-width: 767px) {
	.elementor-headline--style-highlight svg path {
		stroke-width: 6 !important;
	}
	.elementor-headline--style-highlight svg {
		top: 55% !important;
		transform: translate(-50%,-50%) scale(0.8) !important;
transform-origin: center bottom !important;
	}
} */

@media(min-width: 992px) {
	header.header .container ul li .megamenu ul li a svg {
margin-bottom: 40px;
}
	header.header .container ul li .megamenu ul.cols-3 li {
		height: 110px;
	}
}


.elementor-2518 .elementor-element.elementor-element-50c83e7{padding:0px 0px 0px 0px;}#elementor-popup-modal-2518 .dialog-message{width:800px;height:auto;padding:24px 24px 24px 24px;}#elementor-popup-modal-2518{justify-content:center;align-items:center;pointer-events:all;background-color:rgba(0,0,0,.8);}#elementor-popup-modal-2518 .dialog-close-button{display:flex;top:-36px;font-size:24px;}#elementor-popup-modal-2518 .dialog-widget-content{animation-duration:0.5s;border-radius:16px 16px 16px 16px;box-shadow:2px 8px 23px 3px rgba(0,0,0,0.2);}#elementor-popup-modal-2518 .dialog-close-button i{color:#FFFFFF;}#elementor-popup-modal-2518 .dialog-close-button svg{fill:#FFFFFF;}@media(max-width:767px){#elementor-popup-modal-2518 .dialog-message{padding:0px 0px 0px 0px;}}

.tablepress tfoot th, .tablepress thead th{
	background-color:#FFA800;
}

table.tablepress{
	border-radius:16px !important;
	overflow:hidden;
	border:1px solid #e4e4e4;
}

.tablepress thead tr th{
	border:1px solid #e4e4e4 !important;
	background-color:#f7f9fc;
}

.tablepress tbody tr td{
	border:1px solid #e4e4e4 !important;
	vertical-align: middle;
}

.tablepress tr.odd td{
	background-color:#fff;
}

.tablepress thead tr th, .tablepress tr td{
	padding:10px
}

.tablepress i.fa-check{
	color:#2DCC70;
	padding:5px;
	font-size:15px;
}

.tablepress i.fa-times{
	/*color:#ececec;*/
	color:red;
	padding:5px 7px;
	text-align:center;
	font-size:13px
}

.tablepress i.fa-times, .tablepress i.fa-check{
	border-radius:50%;
}

.tablepress tbody tr td:not(:first-child){
	text-align:center;
}

.ms-column{
	padding:0 53px;
}

@media screen and (max-width:1024px){
	.ms-column{
		padding:0 16px;
	}
}

table.tablepress{
	overflow-x:scroll;
	display:block;
}

footer.footer h4 {
	margin-top: 0;
}

@media(max-width: 767px) {
	header.header .container .logo {
		width: 140px;
		height: 47px;
		padding-bottom: 0;
		padding-top: 3px;
	}
	.elementor-widget-theme-post-featured-image picture {
		display: block;
/* 		min-height: 64vw; */
	}
	.elementor-widget .elementor-icon-list-items.elementor-inline-items .elementor-icon-list-item {
		margin-right: 20px !important;
	}
	.elementor-widget .elementor-icon-list-items.elementor-inline-items .elementor-icon-list-item:after {
		display: none;
	}
}

.text-center {
	text-align: center;
}

.plan-table p {
	margin-top: 5px;
}

/* ukrycie banerów rotacyjnych na custom posts */

.case-studies-template-default .article-banner, .ebooks-template-default .article-banner{
	display:none;
}




/* top banner */
.topbanner {
	background: linear-gradient(90deg, #24135C 0%, #431299 100%);
	color: #fff;
	position: absolute;
	font-family: "Plus Jakarta Sans";
	top: 0;
	left: 0;
	width: 100%;
	z-index: 9;
	padding: 8px 0 12px;
	min-height: 40px;
	text-align: center;
}
.topbanner a {
	font-size: 15px;
	line-height: 20px;
	letter-spacing: 0;
	color: #fff;
	text-decoration: none;
	vertical-align: middle;
	margin-left: 0;
	font-weight: 400;
	display: block;
}
.topbanner a:hover {
	text-decoration: none;
	color: #fff;
	cursor: pointer;
}
.topbanner span {
	text-decoration: underline;
	display: inline-block;
	margin-left: 4px;
}

body.has-topbanner .topbar {
	top: 40px;
}
body.has-topbanner header.header:not(.fixed) {
	top: 85px;
}
@media(max-width: 767px) {
	body.has-topbanner {
		padding-top: 40px;
	}
		body.has-topbanner header.header:not(.fixed) {
		top: 60px;
	}
	body.has-topbanner header.header .main-header-menu {
		padding-top: 150px;
	}
}

body.admin-bar {
	padding-top: 32px;
}
body.admin-bar .topbanner {
	top: 32px;
}
body.admin-bar .topbar {
	top: 40px;
}
body.admin-bar.has-topbanner .topbar {
	top: 72px;
}
body.admin-bar header.header:not(.fixed) {
	top: 77px;
}
body.admin-bar.has-topbanner header.header:not(.fixed) {
	top: 117px;
}
body.admin-bar header.header.fixed {
	top: 32px;
}
body.has-topbanner header.header .container ul li .megamenu.full {
	top: 157px;
}
body.admin-bar header.header .container ul li .megamenu.full {
	top: 149px;
}
body.admin-bar.has-topbanner header.header .container ul li .megamenu.full {
	top: 189px;
}

@media(max-width: 991px) {
	header.header .container ul li .megamenu ul.cols-3 {
		display: flex;
		flex-wrap: wrap;
	}
	header.header .container ul li .megamenu ul.cols-3 li {
		width: 100%;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(1) {
		order: 1;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(2) {
		order: 4;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(3) {
		order: 7;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(4) {
		order: 2;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(5) {
		order: 5;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(6) {
		order: 8;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(7) {
		order: 3;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(8) {
		order: 6;
	}
	header.header .container ul li .megamenu ul.cols-3 li:nth-child(9) {
		order: 9;
	}
}

[lang="en-US"] body:not(.elementor-editor-active) #webinar-banner, [lang="es-ES"] body:not(.elementor-editor-active) #webinar-banner {
	display: none;
} 


.single-post .elementor iframe {
	min-height: 455px;
}
@media(max-width: 767px) {
	.single-post .elementor iframe {
		min-height: auto;
	}
}

@media(max-width: 991px) and (min-width: 768px) {
    .col-sm-4 {
        flex: 0 0 auto;
        width: 33.333333333%;
    }
}

footer.footer .additional-links {
    background: #f7f9fc;
	border:1px solid #e4e4e4;
	border-radius:8px;
}

.lp-accordion .elementor-accordion .elementor-accordion-item:not(:last-child){
	border-bottom:1px solid #e4e4e4 !important;
}

.lp-accordion .elementor-tab-title, .lp-accordion .elementor-tab-content{
	padding-left:0 !important;
	padding-right:0 !important;
} 


.series-list-container {
    border: 1px solid #E4E4E4;
    border-radius: 4px;
    padding: 24px 24px 14px 24px;
    font-size: 16px;
}
.series-list-container p {
    margin: 0 0 10px 0;
    font-size: 16px;
	  line-height: 1.5;
}
.series-list-container p a {
    color: #111111;
}
.series-list-container p a.active {
	color: #8B38CB;
	font-weight: 700;
}

@media(max-width: 767px) {
	.elementor-2346 .elementor-element.elementor-element-e0b040a .elementor-icon-list-icon {
		height: 14px;
	}
	header.header .container .right {
		height: 54px;
	}
	.elementor-share-btn__icon i {
		height: 24px;
	}
	.elementor-share-btn {
		height: 54px !important;
	}
}


header.header, header.header .container ul li .megamenu, .btn, .topbar, footer.footer {
font-family: "Plus Jakarta Sans";
}

.ecs-posts article {
    height: 100%;
}
.ecs-posts article .type-post {
    height: 100%;
}
.ecs-posts article .type-post section {
    height: 100%;
}
.ecs-posts article .type-post section .elementor-container {
     height: 100%;
}

/* blog headers fix */

.post-template-default h2 span, .post-template-default h3 span, .post-template-default h4 span{
	font-weight:800 !important;
}

.cky-accordion-header .cky-accordion-btn:hover, .cky-preference-header .cky-btn-close:hover, .cky-preference-content-wrapper .cky-show-desc-btn:hover {
	background: transparent;
}
.cky-preference-content-wrapper .cky-show-desc-btn:hover {
	color: black;
}
.elementor-kit-2031 .cky-notice button {
	border-radius: 10px;
	padding: 10px 16px 11px 16px;
	line-height: 1.5;
	font-weight: 400;
}
@media(max-width: 767px) {
	.elementor-kit-2031 .cky-notice button {
		font-size: 12px;
	}
}

.elementor-slideshow__title {
	text-align: center;
}

html[lang="es-ES"] .elementor-widget-theme-post-title .elementor-heading-title {
	text-transform: initial !important;
}

.single-post .elementor-widget-text-editor h4, .single-post .elementor-widget-text-editor h5, .single-post .elementor-widget-text-editor h6 {
	margin-top: 0 !important;
	margin-bottom: 24px;
}

@media(max-width: 767px) {
	.elementor-kit-2031 {
		line-height: 1.7;
		/*font-size: 14px;*/
	}
	.single-post .elementor-widget-text-editor p {
		margin-bottom: 20px;
		line-height: 1.7;
	}
	.single-post .elementor-widget-text-editor h4, .single-post .elementor-widget-text-editor h5, .single-post .elementor-widget-text-editor h6 {
		margin-bottom: 20px;
	}
}
@media(min-width: 768px) {
.elementor-grid-3 .elementor-grid.ecs-posts article:last-child:nth-child(3n - 2) {
          grid-column-end: 3;
        }
}

@media(max-width: 767px) {
	.elementor-widget-text-editor ul li {
		line-height: 1.7;
	}
}
		</style>
		    </head>
<body class="error404 elementor-default elementor-kit-2031">
<script data-cfasync="false" data-no-defer="1" data-no-minify="1" data-no-optimize="1">if(typeof ewww_webp_supported==="undefined"){var ewww_webp_supported=!1}if(ewww_webp_supported){document.body.classList.add("webp-support")}</script>

      

 
<style>
    header.header .container ul li .megamenu .is-left, header.header .container ul li .megamenu .is-right {
        padding: 16px 16px 24px 16px;
        flex-basis: 50%;
        border: none;
    }
    header.header .container ul li .megamenu ul li {
        margin: 0 -8px;
    }
    header.header .container ul li .megamenu ul li .a {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        min-width: 160px;
    }
    header.header .container ul li .megamenu ul li .a span {
        display: block;
        width: 100%;
    }
    header.header .container ul li .megamenu ul li .a img {
        width: 32px;
        height: auto;
        margin-right: 10px;
    }
    header.header .container ul li .megamenu ul li .a div {
        width: calc(100% - 42px);
        padding-right: 24px;
        padding-bottom: 3px;
    }
    header.header .container ul li .megamenu ul li .a div:after {
        content: '';
        width: 16px;
        height: 16px;
        display: inline-block;
        vertical-align: middle;
        background: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/fi_arrow-right.svg) center center no-repeat;
        background-size: contain;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        right: 13px;
        opacity: 0;
        transition: all 0.3s;
    }
    header.header .container ul li .megamenu ul li .a:hover div:after {
        opacity: 1;
        right: 8px;
    }
    header.header .container ul li .megamenu ul li .a {
        font-size: 16px;
        padding: 8px;
        border-radius: 8px;
        line-height: 1.6;
        font-weight: 600;
    }
    header.header .container ul li .megamenu ul li .a span {
        font-size: 13px;
        color: #343434;
        font-weight: 400;
        margin: 0;
    }
    header.header .container ul li .megamenu ul.cols-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        column-gap: 16px;
        row-gap: 8px;
        margin: 0 -8px;
    }
    header.header .container ul li .megamenu h5 {
        margin: 0 0 14px 0;
        color: #343434;
        font-family: "Plus Jakarta Sans";
        font-size: 14px;
        line-height: 16px;
        letter-spacing: 0;
        font-weight: 400;
        text-transform: none;
        white-space: nowrap;
        border-bottom: 1px solid #E4E4E4;
        padding: 8px 0;
    }
    header.header .container ul li .megamenu {
        box-shadow: 0px 16px 16px rgba(0, 0, 0, 0.1);
        border-radius: 0;
        left: 0;
        padding: 0 8px;
    }
    header.header .container ul li .megamenu.full {
        box-shadow: 0px 16px 16px rgba(0, 0, 0, 0.1);
        border-radius: 0;
        max-width: 100vw;
        padding: 0 calc((100vw - 1248px) / 2);
        transform: translateX(-50%) translateY(10px);;
    }
    header.header .container ul li .megamenu .is-bottom {
        padding: 22px 0 25px;
        border-top: none;
        text-align: center;
        background: #F7F9FC;
        position: relative;
    }
    header.header .container ul li .megamenu .is-bottom:before {
        content: '';
        width: 100vw;
        height: 100%;
        left: 50%;
        transform: translateX(-50%);
        display: block;
        background: #F7F9FC;
        position: absolute;
        top: 0;
    }
    header.header .container ul li .megamenu .is-bottom span {
        padding: 0;
        border-bottom: none;
        display: inline-flex;
        align-items: center;
        position: relative;
        font-weight: 500;
        color: #8B38CB !important;
    }
    header.header .container ul li .megamenu .is-bottom span:hover {
        filter: grayscale(100);
    }
    header.header .container ul li .megamenu .is-bottom span:hover .arrow-right {
        margin-left: 10px;
    }
    .arrow-right {
        width: 16px;
        height: 16px;
        display: inline-block;
        vertical-align: middle;
        background: url(https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/fi_arrow-right.svg) center center no-repeat;
        background-size: contain;
        margin-left: 5px;
        transition: all 0.3s;
    }
    header.header .container ul li .megamenu ul li .a:hover {
        color: #111 !important;
        background:#f7f9fc
    }
    header.header .container ul li .megamenu.full ul li a {
        padding: 0;
        border-radius: 0;
        white-space: initial;
    }
    @media(max-width: 991px) {
        header.header .container ul li .megamenu {
            left: 100%;
            box-shadow: none;
            padding: 0;
            top: 120px;
        }
        .header.header .container ul li .megamenu.full {
            max-width: 100%;
            padding: 0;
            transform: none;
            top: 120px;
        }
        header.header .container ul li .megamenu ul li .a:hover {
            background:rgba(0, 0, 0, 0)
        }
        header.header .container ul li .megamenu ul li .a div {
            padding-bottom: 8px;
        }
        header.header .container ul li .megamenu .is-left, header.header .container ul li .megamenu .is-right {
            padding: 16px 32px;
            flex-basis: 100%;
        }
        header.header .container ul li .megamenu ul.cols-2 {
            grid-template-columns: 1fr;
            row-gap: 8px;
        }
        header.header .container .main-header-menu.active + .right .btn {
            opacity: 0;
        }
    }
    
    .topbar {
        z-index: 9;
    }
    
    .topbar .dropdown-menu {
        display: inline-block;
        position: relative;
        padding-bottom: 20px;
        margin-bottom: -20px;    
    }
    .topbar .dropdown-menu ul {
        display: block;
        position: absolute;
        top: 100%;
        left: 0;
        list-style: none;
        padding: 0;
        margin: 0;
        text-align: left;
        white-space: nowrap;
        box-shadow: 0px 16px 16px rgba(0, 0, 0, 0.1);
        border-radius: 0;
        left: 0;
        padding: 14px 16px 16px;
        background: #fff;
        opacity: 0;
        pointer-events: none;
        transform: translateY(10px);
        transition: all .3s;
    }
    .topbar .dropdown-menu:hover ul {
        opacity: 1;
        transform: translateY(0);
        transition: all .3s;
        pointer-events: auto;
    }
    .topbar .dropdown-menu ul a {
        margin: 0;
    }
</style>
  
   
    <div class="topbar">
        <div class="container">
            <a href="https://www.upmenu.com/contact/">Contact</a>
            <a href="https://www.upmenu.com/admin/login" rel="nofollow" target="_blank">Login</a>
            <a href="https://www.upmenu.com/blog/how-to-increase-food-delivery-sales/">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.0001 18.3333C14.6025 18.3333 18.3334 14.6024 18.3334 10C18.3334 5.39763 14.6025 1.66667 10.0001 1.66667C5.39771 1.66667 1.66675 5.39763 1.66675 10C1.66675 14.6024 5.39771 18.3333 10.0001 18.3333Z" stroke="#111111" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M1.66675 10H18.3334" stroke="#111111" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M10.0001 1.66667C12.0845 3.94863 13.269 6.91003 13.3334 10C13.269 13.09 12.0845 16.0514 10.0001 18.3333C7.91568 16.0514 6.73112 13.09 6.66675 10C6.73112 6.91003 7.91568 3.94863 10.0001 1.66667V1.66667Z" stroke="#111111" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                English
                <svg width="8" height="4" viewBox="0 0 8 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 0.5L4 3.5L7 0.5" stroke="#111111" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
            <select class="select-language" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                <option name="en" value="https://www.upmenu.com" selected>English</option>
                <option name="es" value="https://www.upmenu.com/es/">Español</option>
                <option name="pl" value="https://www.upmenu.com/pl/">Polski</option>
            </select>
        </div>
    </div>

    <header class="header">
        <div class="container">
            <a href="https://www.upmenu.com" class="logo">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAAAjAQMAAAB8RHBGAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAA5JREFUGBljGAWjYDACAAKZAAGDJLwyAAAAAElFTkSuQmCC" width="140" height="35" alt="UpMenu - Online Ordering System for Restaurants" title="UpMenu - Online Ordering System for Restaurants" data-src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/logo.svg" decoding="async" class="lazyload" data-eio-rwidth="140" data-eio-rheight="35" /><noscript><img src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/logo.svg" width="140" height="35" alt="UpMenu - Online Ordering System for Restaurants" title="UpMenu - Online Ordering System for Restaurants" data-eio="l" /></noscript>
            </a>
            <div class="main-header-menu">
                <div class="menu-top">
                    <div class="close-megamenu">
                        <a href="#">Back</a>
                    </div>
                    <div>
                        <a href="https://www.upmenu.com/blog/how-to-increase-food-delivery-sales/">
                            English
                            <svg width="8" height="4" viewBox="0 0 8 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 0.5L4 3.5L7 0.5" stroke="#111111" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </a>
                        <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                            <option value="https://www.upmenu.com" selected>English</option>
                            <option value="https://www.upmenu.com/es/">Español</option>
                            <option value="https://www.upmenu.com/pl/">Polski</option>
                        </select>
                    </div>
                    <div>
                        <a href="https://www.upmenu.com/admin/login" target="_blank" rel="nofollow">Login</a>
                    </div>
                </div>
                <ul>
                    <li class="has-megamenu">
                        <a href="#">Features</a>
                        <div class="megamenu full">
                            <div class="is-left">
                                <h5>Sell Food Online</h5>
                                <ul class="cols-2">
                                                                                <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/software-for-restaurants/online-ordering-systems/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Commission-free ordering system on your own website" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/food-ordering-system.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/food-ordering-system.svg" alt="Commission-free ordering system on your own website" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/software-for-restaurants/online-ordering-systems/">Food Ordering System</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-website-builder/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Free restaurant websites with no-code editor" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/website-builder.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/website-builder.svg" alt="Free restaurant websites with no-code editor" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-website-builder/">Website Builder</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/software-for-restaurants/mobile-app-for-restaurant/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="iOS & Android mobile app builder for restaurants" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/mobile-apps.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/mobile-apps.svg" alt="iOS & Android mobile app builder for restaurants" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/software-for-restaurants/mobile-app-for-restaurant/">Mobile Apps</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-website-templates/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Free restaurant & food website templates" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/website-templates.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/website-templates.svg" alt="Free restaurant & food website templates" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-website-templates/">Website Templates</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/software-for-restaurants/table-ordering/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Ordering & payment right from the table" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/tableside-ordering.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/tableside-ordering.svg" alt="Ordering & payment right from the table" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/software-for-restaurants/table-ordering/">Tableside Ordering</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/qr-code-menu/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Free QR code digital menu creator" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/03/qr-code-menu-1.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/03/qr-code-menu-1.svg" alt="Free QR code digital menu creator" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/qr-code-menu/">QR Code Menu</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/google-ordering/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Direct ordering from Google" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/03/google-ordering-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/03/google-ordering-icon.svg" alt="Direct ordering from Google" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/google-ordering/">Google Ordering</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-reservation-system/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Table reservations on your own website" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/reservation-system.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/reservation-system.svg" alt="Table reservations on your own website" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-reservation-system/">Reservation System</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                 </ul>
                            </div>
                            <div class="is-right">
                                <h5>Gain More Customers</h5>
                                <ul class="cols-2">
                                                                                <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/software-for-restaurants/restaurant-marketing-tools/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="All-in-one restaurant marketing software" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/marketing-tools.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/marketing-tools.svg" alt="All-in-one restaurant marketing software" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/software-for-restaurants/restaurant-marketing-tools/">Marketing Tools</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/loyalty-program-and-reward-system/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Restaurant loyalty program & reward system" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/loyalty-program.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/loyalty-program.svg" alt="Restaurant loyalty program & reward system" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/loyalty-program-and-reward-system/">Loyalty Program</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/gift-cards/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Gift cards for restaurants" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/gift-cards.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/gift-cards.svg" alt="Gift cards for restaurants" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/gift-cards/">Gift Cards</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-feedback/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Restaurant feedback form & reputation management" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/feedback-system.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/feedback-system.svg" alt="Restaurant feedback form & reputation management" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-feedback/">Feedback System</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-email-marketing/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Email marketing software for restaurants" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/email-marketing.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/email-marketing.svg" alt="Email marketing software for restaurants" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-email-marketing/">Email Marketing</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-analytics/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Restaurant dashboard & analytics software" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/analytics-reporting.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/analytics-reporting.svg" alt="Restaurant dashboard & analytics software" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-analytics/">Analytics & Reporting</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-sms-marketing/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="Restaurant text message marketing solution" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/sms-marketing.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/sms-marketing.svg" alt="Restaurant text message marketing solution" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-sms-marketing/">SMS Marketing</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/integrations/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="POS & Delivery services integrations" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/02/integrations.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/02/integrations.svg" alt="POS & Delivery services integrations" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/integrations/">Integrations</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                 </ul>
                            </div>
                                                    </div>
                    </li> 
                    <li class="has-megamenu">
                        <a href="#">Restaurant type</a>
                        <div class="megamenu full">
                            <div class="is-left">
                                <ul class="cols-2">
                                                                                <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/multi-unit-restaurant/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/multi-unit-restaurants-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/multi-unit-restaurants-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/multi-unit-restaurant/">Multi-Unit Restaurants</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/franchise/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/chains-franchises-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/chains-franchises-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/franchise/">Chains & Franchises</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/fast-casual/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/fast-casual-restaurants-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/fast-casual-restaurants-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/fast-casual/">Fast Casual Restaurants</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/fine-dining/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/fine-dining-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/fine-dining-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/fine-dining/">Fine Dining</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/food-truck/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/food-trucks-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/food-trucks-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/food-truck/">Food Trucks</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/bakery-software/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/Icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/Icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/bakery-software/">Bakeries</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/hotel-restaurants/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/hotel-restaurants-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/hotel-restaurants-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/hotel-restaurants/">Hotel Restaurants</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/ghost-kitchens/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/ghost-kitchen-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/ghost-kitchen-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/ghost-kitchens/">Ghost Kitchens</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/pizzeria/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/pizzerias-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/pizzerias-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/pizzeria/">Pizzerias</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/nightclubs/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/clubs-nightlife-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/clubs-nightlife-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/nightclubs/">Clubs & Nightlife</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/winery/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/wineries-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/wineries-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/winery/">Wineries</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/restaurant-delivery-software/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/Icon-1.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/Icon-1.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/restaurant-delivery-software/">Delivery</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                 </ul>
                            </div>
                            <div class="is-right">
                                <ul class="cols-2">
                                                                                <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/hospitality-groups/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/hospitality-1.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/hospitality-1.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/hospitality-groups/">Hospitality Groups</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/quick-service/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/quick-service-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/quick-service-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/quick-service/">Quick Service</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/casual-dining/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/casual-dining-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/casual-dining-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/casual-dining/">Casual Dining</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/full-service/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/full-service-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/full-service-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/full-service/">Full Service</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/food-halls/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/food-halls-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/food-halls-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/food-halls/">Food Halls</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/software-for-restaurants/portal/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/Icon-2.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/Icon-2.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/software-for-restaurants/portal/">Portal</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/catering-software/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/catering-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/catering-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/catering-software/">Catering</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/sushi/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/sushi-hibachi-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/sushi-hibachi-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/sushi/">Sushi</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/bar/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/bars-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/bars-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/bar/">Bars</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/brewery/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/breweries-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/breweries-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/brewery/">Breweries</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                             <li>
                                                                                                <div class="a">
                                                    <a href="https://www.upmenu.com/coffee-shops/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1jGOQAAACgAAGXmq1SAAAAAElFTkSuQmCC" alt="" width="32" height="32" data-src="https://www.upmenu.com/wp-content/uploads/2023/12/hospitality-groups-icon.svg" decoding="async" class="lazyload" data-eio-rwidth="32" data-eio-rheight="32" /><noscript><img src="https://www.upmenu.com/wp-content/uploads/2023/12/hospitality-groups-icon.svg" alt="" width="32" height="32" data-eio="l" /></noscript></a>
                                                    <div>
                                                        <a href="https://www.upmenu.com/coffee-shops/">Coffee Shops</a>
                                                                                                            </div>
                                                </div>
                                            </li>                                 </ul>
                            </div>
                        </div>
                    </li> 
                    <li>
                        <a href="https://www.upmenu.com/pricing/">Pricing</a>
                    </li>
                    <li class="has-megamenu">
                        <a href="#">Resources</a>
                        <div class="megamenu">
                            <div class="is-left">
                                <h5>Learn</h5>
                                <ul>
                                    <li><a class="a" href="https://www.upmenu.com/blog/">Blog</a></li>
                                    <li><a class="a" href="https://help.upmenu.com/en/">Help</a></li>
                                    <li><a class="a" href="https://www.upmenu.com/experts/">Experts</a></li>
                                    <li><a class="a" href="https://www.upmenu.com/ebooks/">Ebooks</a></li>
                                    <li><a class="a" href="https://app.getbeamer.com/upmenu/en" rel="nofollow" target="_blank">What's New</a></li>
                                </ul>
                            </div>
                            <div class="is-right">
                                <h5>Customers</h5>
                                <ul>
                                    <li><a class="a" href="https://www.upmenu.com/software-for-restaurants/portfolio/">Customers</a></li>
                                    <li><a class="a" href="https://www.upmenu.com/case-studies/">Success stories</a></li>
                                    <li><a class="a" href="https://www.upmenu.com#testimonials" rel="nofollow">Testimonials</a></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                                        <li class="has-megamenu">
                        <a href="#">Partnership</a>
                        <div class="megamenu"> 
                            <div class="is-left">
                                <h5>Partnership</h5>
                                <ul>
                                    <li><a class="a" href="https://www.upmenu.com/affiliate-program/">Affiliate program</a></li>
                                    <li><a class="a" href="https://www.upmenu.com/reseller-program/">Reseller program</a></li>
                                </ul> 
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="menu-bottom">
                    <a href="https://www.upmenu.com/admin/registration?lang=en" rel="nofollow" class="btn btn-upmenu register-top-nav">Start Free Trial</a>
                </div>
            </div>
            <div class="right">
                <a href="https://www.upmenu.com/admin/registration?lang=en" rel="nofollow" class="btn btn-upmenu register-top-nav hide-mobile">Start Free Trial</a>
                <a href="https://www.upmenu.com/admin/registration?lang=en" rel="nofollow" class="btn btn-upmenu register-top-nav show-mobile">Start Free Trial</a>
                <a href="#" class="hamburger show-mobile">
                    <span></span>
                    <span></span>
                    <span></span>
                </a>
            </div>
        </div>
    </header>
    





    <div style="padding: 200px 0 120px 0;">
        <div class="container">
                            <h2>Error 404</h2>
                <p>
                    Page not found
                </p>
                <a href="https://www.upmenu.com" class="btn btn-upmenu">Back to homepage</a>
                                            </div>
    </div>


<script nitro-exclude>
    var heartbeatData = new FormData(); heartbeatData.append('nitroHeartbeat', '1');
    fetch(location.href, {method: 'POST', body: heartbeatData, credentials: 'omit'});
</script>
<script nitro-exclude>
    document.cookie = 'nitroCachedPage=' + (!window.NITROPACK_STATE ? '0' : '1') + '; path=/; SameSite=Lax';
</script>        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-6 col-sm-4 col-md-2">
                        <a href="https://www.upmenu.com" class="logo">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAAAjAQMAAAB8RHBGAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAA5JREFUGBljGAWjYDACAAKZAAGDJLwyAAAAAElFTkSuQmCC" width="140" height="35" alt="UpMenu Logo" title="UpMenu Logo" data-src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/logo-black.svg" decoding="async" class="lazyload" data-eio-rwidth="140" data-eio-rheight="35" /><noscript><img src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/logo-black.svg" width="140" height="35" alt="UpMenu Logo" title="UpMenu Logo" data-eio="l" /></noscript>
                        </a>
                        <p>
                            © upmenu.com <br/>2008-2023                        </p>
                        <a href="https://www.facebook.com/UpMenuCom/" target="_blank" class="social">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAZAQMAAAAR5XweAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1joAMAAABkAAHCKMZFAAAAAElFTkSuQmCC" width="24" height="25" alt="UpMenu Facebook" data-src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/facebook.svg" decoding="async" class="lazyload" data-eio-rwidth="24" data-eio-rheight="25" /><noscript><img src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/facebook.svg" width="24" height="25" alt="UpMenu Facebook" data-eio="l" /></noscript>
                        </a>
                        <a href="https://www.instagram.com/upmenucom/" target="_blank" class="social">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAZAQMAAAAR5XweAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1joAMAAABkAAHCKMZFAAAAAElFTkSuQmCC" width="24" height="25" alt="UpMenu Instagram" data-src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/instagram.svg" decoding="async" class="lazyload" data-eio-rwidth="24" data-eio-rheight="25" /><noscript><img src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/instagram.svg" width="24" height="25" alt="UpMenu Instagram" data-eio="l" /></noscript>
                        </a>
                        <a href="https://www.linkedin.com/company/upmenu" target="_blank" class="social">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAZAQMAAAAR5XweAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAAtJREFUCB1joAMAAABkAAHCKMZFAAAAAElFTkSuQmCC" width="24" height="25" alt="UpMenu LinkedIn" data-src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/linkedin.svg" decoding="async" class="lazyload" data-eio-rwidth="24" data-eio-rheight="25" /><noscript><img src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/img/linkedin.svg" width="24" height="25" alt="UpMenu LinkedIn" data-eio="l" /></noscript>
                        </a>
                    </div>
                    <div class="col-6 col-sm-4 col-md-2">
                        <h4>Features</h4>
                        <ul>
                                                                                                    <li><a href="https://www.upmenu.com/software-for-restaurants/online-ordering-systems/" target="_self">Food Ordering System</a></li>                                                                         <li><a href="https://www.upmenu.com/software-for-restaurants/mobile-app-for-restaurant/" target="_self">Mobile Apps</a></li>                                                                         <li><a href="https://www.upmenu.com/restaurant-website-builder/" target="_self">Website Builder</a></li>                                                                         <li><a href="https://www.upmenu.com/restaurant-website-templates/" target="_self">Website Templates</a></li>                                                                         <li><a href="https://www.upmenu.com/menu-templates/" target="_self">Menu Templates</a></li>                                                                         <li><a href="https://www.upmenu.com/software-for-restaurants/table-ordering/" target="_self">Tableside Ordering</a></li>                                                                         <li><a href="https://www.upmenu.com/qr-code-menu/" target="_self">QR Code Menu</a></li>                                                                         <li><a href="https://www.upmenu.com/google-ordering/" target="_self">Google Ordering</a></li>                                                                         <li><a href="https://www.upmenu.com/restaurant-reservation-system/" target="_self">Reservation System</a></li>                                                                         <li><a href="https://www.upmenu.com/software-for-restaurants/restaurant-marketing-tools/" target="_self">Marketing Tools</a></li>                                                                         <li><a href="https://www.upmenu.com/loyalty-program-and-reward-system/" target="_self">Loyalty Program</a></li>                                                                         <li><a href="https://www.upmenu.com/gift-cards/" target="_self">Gift Cards</a></li>                                                                         <li><a href="https://www.upmenu.com/restaurant-feedback/" target="_self">Feedback System</a></li>                                                                         <li><a href="https://www.upmenu.com/restaurant-email-marketing/" target="_self">Email Marketing</a></li>                                                                         <li><a href="https://www.upmenu.com/restaurant-analytics/" target="_self">Analytics &amp; Reporting</a></li>                                                                         <li><a href="https://www.upmenu.com/restaurant-sms-marketing/" target="_self">SMS Marketing</a></li>                                                                         <li><a href="https://www.upmenu.com/integrations/" target="_self">Integrations</a></li>                         </ul>
                    </div>
                    <div class="col-6 col-sm-4 col-md-2">
                        <h4>Company</h4>
                        <ul>
                                                                                                    <li><a href="https://www.upmenu.com/pricing/" target="_self" >Pricing</a></li>                                                                         <li><a href="https://www.upmenu.com/contact/" target="_self" >Contact</a></li>                                                                         <li><a href="https://www.upmenu.com/about-us/" target="_self" >About Us</a></li>                                                                         <li><a href="https://www.upmenu.com/terms-and-conditions/" target="_self" >Terms and conditions</a></li>                                                                         <li><a href="https://www.upmenu.com/privacy-policy/" target="_self" >Privacy policy</a></li>                                                                         <li><a href="#" target="_self" rel="nofollow">Cookie Settings</a></li>                         </ul>
                    </div>
                    <div class="col-6 col-sm-4 col-md-2">
                        <h4>Resources</h4>
                        <ul>
                                                                                                    <li><a href="https://help.upmenu.com/en/articles/4466222-getting-started-with-upmenu" target="_self" >Start in 5 minutes</a></li>                                                                         <li><a href="https://www.upmenu.com/blog/" target="_self" >Blog</a></li>                                                                         <li><a href="https://help.upmenu.com/en/" target="_self" >Help Center</a></li>                                                                         <li><a href="https://www.upmenu.com/experts/" target="_self" >Experts</a></li>                                                                         <li><a href="https://www.upmenu.com/ebooks/" target="_self" >Ebooks</a></li>                                                                         <li><a href="https://app.getbeamer.com/upmenu/en" target="_self" >What&#039;s New</a></li>                                                                         <li><a href="https://www.upmenu.com/software-for-restaurants/portfolio/" target="_self" >Customers</a></li>                                                                         <li><a href="https://www.upmenu.com/case-studies/" target="_self" >Success stories</a></li>                                                                         <li><a href="https://www.upmenu.com#testimonials" target="_self" >Testimonials</a></li>                                                                         <li><a href="https://bit.ly/3AdDZ8U" target="_blank" rel="nofollow">System status</a></li>                                                                         <li><a href="https://www.upmenu.com/api/documentation/" target="_self" >API Docs</a></li>                         </ul>
                    </div>
                    <div class="col-6 col-sm-4 col-md-2">
                        <h4>Partnership</h4>
                        <ul>
                                                                                                    <li><a href="https://www.upmenu.com/affiliate-program/" target="_self">Affiliate program</a></li>                                                                         <li><a href="https://www.upmenu.com/reseller-program/" target="_self">Reseller program</a></li>                                                                         <li><a href="https://www.upmenu.com/terms-and-conditions-of-affiliate-partnership-program/" target="_self">Affiliate program ToC</a></li>                                                                         <li><a href="https://www.upmenu.com/terms-and-conditions-of-reseller-partnership-program/" target="_self">Reseller program ToC</a></li>                         </ul>
                    </div>
                    <div class="col-6 col-sm-4 col-md-2">
                        <h4>Demo</h4>
                        <ul>
                                                                                                    <li><a href="https://ninjagrill.upmenusite.com/menu" target="_blank">Online orders</a></li>                                                                         <li><a href="https://play.google.com/store/apps/details?id=com.upmenu.upMenuDemo" target="_blank">Mobile apps (Android)</a></li>                                                                         <li><a href="https://apps.apple.com/pl/app/ninjagrill/id1397841631" target="_blank">Mobile apps (IOS)</a></li>                         </ul>
                    </div>
                </div>
                                    <div class="additional-links">
                        <div class="row">
                            <div class="col-sm-12 lp-navigation-list">
                                <a href="https://www.upmenu.com/alternatives/">»&nbsp;Alternatives</a>
                                <a href="https://www.upmenu.com/grubhub-alternative/">»&nbsp;GrubHub Alternative</a>
                                <a href="https://www.upmenu.com/alternatives/for-seamless/">»&nbsp;Seamless Alternative</a>
                                <a href="https://www.upmenu.com/alternatives/for-foodpanda/">»&nbsp;Foodpanda Alternative</a>
                                <a href="https://www.upmenu.com/alternatives/for-justeat/">»&nbsp;Justeat Alternative</a>
                                <a href="https://www.upmenu.com/ubereats-alternative/">»&nbsp;UberEats Alternative</a>
                                <a href="https://www.upmenu.com/woocommerce-alternative/">»&nbsp;WooCommerce Alternative</a>
                                <a href="https://www.upmenu.com/alternatives/for-caviar/">»&nbsp;Caviar Alternative</a>
                                <a href="https://www.upmenu.com/doordash-alternative/">»&nbsp;DoorDash Alternative</a>
                                <a href="https://www.upmenu.com/alternatives/for-deliveryhero/">»&nbsp;DeliveryHero Alternative</a>
                                <a href="https://www.upmenu.com/chownow-alternative/">»&nbsp;ChowNow Alternative</a>
                                <a href="https://www.upmenu.com/gloriafood-alternative/">»&nbsp;GloriaFood Alternative</a>
                                <a href="https://www.upmenu.com/bentobox/">»&nbsp;BentoBox Alternative</a>
                            </div>
                        </div>
                    </div>
                            </div>
        </footer>

        		<div data-elementor-type="popup" data-elementor-id="2518" class="elementor elementor-2518" data-elementor-settings="{&quot;entrance_animation&quot;:&quot;fadeIn&quot;,&quot;exit_animation&quot;:&quot;fadeIn&quot;,&quot;entrance_animation_duration&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0.5,&quot;sizes&quot;:[]},&quot;a11y_navigation&quot;:&quot;yes&quot;,&quot;timing&quot;:[]}" data-elementor-post-type="elementor_library">
								<section class="elementor-section elementor-top-section elementor-element elementor-element-50c83e7 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="50c83e7" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e5724ea" data-id="e5724ea" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-03d3636 elementor-widget elementor-widget-video" data-id="03d3636" data-element_type="widget" data-settings="{&quot;youtube_url&quot;:&quot;https:\/\/youtu.be\/T--fhGL16tY&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;video_type&quot;:&quot;youtube&quot;}" data-widget_type="video.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.17.0 - 08-11-2023 */
.elementor-widget-video .elementor-widget-container{overflow:hidden;transform:translateZ(0)}.elementor-widget-video .elementor-wrapper{aspect-ratio:var(--video-aspect-ratio)}.elementor-widget-video .elementor-wrapper iframe,.elementor-widget-video .elementor-wrapper video{height:100%;width:100%;display:flex;border:none;background-color:#000}@supports not (aspect-ratio:1/1){.elementor-widget-video .elementor-wrapper{position:relative;overflow:hidden;height:0;padding-bottom:calc(100% / var(--video-aspect-ratio))}.elementor-widget-video .elementor-wrapper iframe,.elementor-widget-video .elementor-wrapper video{position:absolute;top:0;right:0;bottom:0;left:0}}.elementor-widget-video .elementor-open-inline .elementor-custom-embed-image-overlay{position:absolute;top:0;right:0;bottom:0;left:0;background-size:cover;background-position:50%}.elementor-widget-video .elementor-custom-embed-image-overlay{cursor:pointer;text-align:center}.elementor-widget-video .elementor-custom-embed-image-overlay:hover .elementor-custom-embed-play i{opacity:1}.elementor-widget-video .elementor-custom-embed-image-overlay img{display:block;width:100%;aspect-ratio:var(--video-aspect-ratio);-o-object-fit:cover;object-fit:cover;-o-object-position:center center;object-position:center center}@supports not (aspect-ratio:1/1){.elementor-widget-video .elementor-custom-embed-image-overlay{position:relative;overflow:hidden;height:0;padding-bottom:calc(100% / var(--video-aspect-ratio))}.elementor-widget-video .elementor-custom-embed-image-overlay img{position:absolute;top:0;right:0;bottom:0;left:0}}.elementor-widget-video .e-hosted-video .elementor-video{-o-object-fit:cover;object-fit:cover}.e-con-inner>.elementor-widget-video,.e-con>.elementor-widget-video{width:var(--container-widget-width);--flex-grow:var(--container-widget-flex-grow)}</style>		<div class="elementor-wrapper elementor-open-inline">
			<div class="elementor-video"></div>		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
		        
        <script>
            jQuery('footer.footer .col-md-2:nth-child(3) ul li:last-child a').click( function(e) {
                e.preventDefault();
                jQuery('.cky-btn-revisit').trigger('click');
            });            
        </script>
        
                        
        <!-- intercom 
<script>
	window.intercomSettings = {
		app_id: "vhiyiyey"
	};
</script>
<script>
	(function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic('reattach_activator');ic('update',w.intercomSettings);}else{var d=document;var i=function(){i.c(arguments);};i.q=[];i.c=function(args){i.q.push(args);};w.Intercom=i;var l=function(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/vhiyiyey';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);};if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
-->

<!-- FACEBOOK PIXEL CODE -->
<script>
        !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','//connect.facebook.net/en_US/fbevents.js');
        // Insert Your Facebook Pixel ID below. 
        fbq('init', '343181015843058');
        fbq('track', 'PageView');
</script>
<!-- FACEBOOK PIXEL CODE -->

<!-- USER.COM
<script type="text/javascript" data-cfasync="false">window.civchat = {apiKey: "iP71FA"};</script>
-->

<!-- LINKEDIN
<script type="text/javascript">
        _linkedin_partner_id = "2489282";
        window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
        window._linkedin_data_partner_ids.push(_linkedin_partner_id);
        </script><script type="text/javascript">
        (function(){var s = document.getElementsByTagName("script")[0];
        var b = document.createElement("script");
        b.type = "text/javascript";b.async = true;
        b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
        s.parentNode.insertBefore(b, s);})();
</script>
-->

<script>
 var intercomLoader = function() {
  (function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic('reattach_activator');ic('update',w.intercomSettings);}else{var d=document;var i=function(){i.c(arguments);};i.q=[];i.c=function(args){i.q.push(args);};w.Intercom=i;var l=function(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/vhiyiyey';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);};if(document.readyState==='complete'){l();}else if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
  window.Intercom('boot', {
   app_id: 'vhiyiyey'
  })
  window.removeEventListener('scroll', intercomLoader);
 }
 window.addEventListener('scroll', intercomLoader);
</script>		<div data-elementor-type="popup" data-elementor-id="17924" class="elementor elementor-17924 elementor-location-popup" data-elementor-settings="{&quot;entrance_animation&quot;:&quot;fadeIn&quot;,&quot;exit_animation&quot;:&quot;fadeIn&quot;,&quot;entrance_animation_duration&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0.5,&quot;sizes&quot;:[]},&quot;a11y_navigation&quot;:&quot;yes&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}" data-elementor-post-type="elementor_library">
								<section class="elementor-section elementor-top-section elementor-element elementor-element-c191b52 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c191b52" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9ba2304" data-id="9ba2304" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-aad30fc elementor-view-default elementor-widget elementor-widget-icon" data-id="aad30fc" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="#elementor-action%3Aaction%3Dpopup%3Aclose%26settings%3DeyJkb19ub3Rfc2hvd19hZ2FpbiI6IiJ9">
			<i aria-hidden="true" class="fas fa-times"></i>			</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-f925b4c elementor-search-form--skin-classic elementor-search-form--button-type-icon elementor-search-form--icon-search elementor-widget elementor-widget-search-form" data-id="f925b4c" data-element_type="widget" data-settings="{&quot;skin&quot;:&quot;classic&quot;}" data-widget_type="search-form.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="https://www.upmenu.com/wp-content/plugins/elementor-pro/assets/css/widget-theme-elements.min.css">		<form class="elementor-search-form" action="https://www.upmenu.com" method="get" role="search">
									<div class="elementor-search-form__container">
				<label class="elementor-screen-only" for="elementor-search-form-f925b4c">Search</label>

				
				<input id="elementor-search-form-f925b4c" placeholder="Search..." class="elementor-search-form__input" type="search" name="s" value="">
				
									<button class="elementor-search-form__submit" type="submit" aria-label="Search">
													<i aria-hidden="true" class="fas fa-search"></i>							<span class="elementor-screen-only">Search</span>
											</button>
				
							</div>
		</form>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
		<link rel='stylesheet' id='elementor-post-2518-css' href='https://www.upmenu.com/wp-content/uploads/elementor/css/post-2518.css?ver=1701268604' type='text/css' media='all' />
<link rel='stylesheet' id='e-animations-css' href='https://www.upmenu.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.17.3' type='text/css' media='all' />
<script type="text/javascript" id="eio-lazy-load-js-before">
/* <![CDATA[ */
var eio_lazy_vars = {"exactdn_domain":"","skip_autoscale":0,"threshold":0};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/ewww-image-optimizer/includes/lazysizes.min.js?ver=721" id="eio-lazy-load-js"></script>
<script type="text/javascript" id="site_tracking-js-extra">
/* <![CDATA[ */
var php_data = {"ac_settings":{"tracking_actid":27697870,"site_tracking_default":1},"user_email":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/activecampaign-subscription-forms/site_tracking.js?ver=6.4.2" id="site_tracking-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/themes/upmenucom/assets/js/functions.js?ver=1.15" id="functions-js"></script>
<script type="text/javascript" id="site-reviews-js-before">
/* <![CDATA[ */
window.hasOwnProperty("GLSR")||(window.GLSR={Event:{on:()=>{}}});GLSR.action="glsr_action";GLSR.addons=[];GLSR.ajaxpagination=["#wpadminbar",".site-navigation-fixed"];GLSR.ajaxurl="https://www.upmenu.com/wp-admin/admin-ajax.php";GLSR.captcha=[];GLSR.nameprefix="site-reviews";GLSR.starsconfig={"clearable":false,"tooltip":false};GLSR.state={"popstate":false};GLSR.text={closemodal:"Close Modal"};GLSR.urlparameter="reviews-page";GLSR.validationconfig={field:"glsr-field",form:"glsr-form","field_error":"glsr-field-is-invalid","field_message":"glsr-field-error","field_required":"glsr-required","field_valid":"glsr-field-is-valid","form_error":"glsr-form-is-invalid","form_message":"glsr-form-message","form_message_failed":"glsr-form-failed","form_message_success":"glsr-form-success","input_error":"glsr-is-invalid","input_valid":"glsr-is-valid"};GLSR.validationstrings={accepted:"This field must be accepted.",between:"This field value must be between %s and %s.",betweenlength:"This field must have between %s and %s characters.",email:"This field requires a valid e-mail address.",errors:"Please fix the submission errors.",max:"Maximum value for this field is %s.",maxlength:"This field allows a maximum of %s characters.",min:"Minimum value for this field is %s.",minlength:"This field requires a minimum of %s characters.",number:"This field requires a number.",pattern:"Please match the requested format.",regex:"Please match the requested format.",required:"This field is required.",tel:"This field requires a valid telephone number.",url:"This field requires a valid website URL (make sure it starts with http or https).",unsupported:"The review could not be submitted because this browser is too old. Please try again with a modern browser."};GLSR.version="6.11.4";
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/site-reviews/assets/scripts/site-reviews.js?ver=6.11.4" id="site-reviews-js"></script>
<script type="text/javascript" id="site-reviews-js-after">
/* <![CDATA[ */
function glsr_init_elementor(){GLSR.Event.trigger("site-reviews/init")}"undefined"!==typeof jQuery&&(jQuery(document).on("elementor/popup/show",glsr_init_elementor),jQuery(window).on("elementor/frontend/init",function(){elementorFrontend.hooks.addAction("frontend/element_ready/site_review.default",glsr_init_elementor);elementorFrontend.hooks.addAction("frontend/element_ready/site_reviews.default",glsr_init_elementor);elementorFrontend.hooks.addAction("frontend/element_ready/site_reviews_form.default",glsr_init_elementor);}));
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.17.1" id="elementor-pro-webpack-runtime-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.17.3" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.17.3" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/dist/hooks.min.js?ver=c6aec9a8d4e5a5d543a1" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/dist/i18n.min.js?ver=7701b0c3857f914212ef" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="elementor-pro-frontend-js-before">
/* <![CDATA[ */
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/www.upmenu.com\/wp-admin\/admin-ajax.php","nonce":"de0f0dd7b6","urls":{"assets":"https:\/\/www.upmenu.com\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/www.upmenu.com\/wp-json\/"},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"en_US","app_id":"785955475778577"},"lottie":{"defaultAnimationUrl":"https:\/\/www.upmenu.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.17.1" id="elementor-pro-frontend-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.17.3","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"additional_custom_breakpoints":true,"theme_builder_v2":true,"landing-pages":true,"page-transitions":true,"notes":true,"form-submissions":true,"e_scroll_snap":true},"urls":{"assets":"https:\/\/www.upmenu.com\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper-container","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found | UpMenu","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.17.3" id="elementor-frontend-js"></script>
<script type="text/javascript" src="https://www.upmenu.com/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.17.1" id="pro-elements-handlers-js"></script>
 

	</body>
</html>